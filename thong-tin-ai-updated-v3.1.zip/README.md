# 📚 THÔNG TIN AI - AI Tools Directory & Information Hub

## 🎯 Giới thiệu / Introduction

**THÔNG TIN AI** là một trang web toàn diện để khám phá, tìm kiếm và so sánh các công cụ AI tốt nhất. Được thiết kế cho:
- 👨‍💼 Chuyên gia kinh doanh
- 💻 Lập trình viên & nhà phát triển
- 🎨 Nhà thiết kế & sáng tạo viên
- 📚 Sinh viên & người học tập
- 🏢 Doanh nghiệp & Startup

**Features:**
✨ 500+ công cụ AI chất lượng
🔍 Tìm kiếm nhanh và lọc thông minh
🌙 Chế độ tối/sáng
🌐 Hỗ trợ 2 ngôn ngữ (Tiếng Việt & English)
📱 Hoàn toàn Responsive (Desktop, Tablet, Mobile)
⚡ Nhanh, nhẹ, không yêu cầu backend
🎯 Bảng xếp hạng, Yêu thích, AI mới nhất

---

## 📦 Yêu cầu hệ thống / System Requirements

- Node.js 14+ (tùy chọn, chỉ cần cho development)
- Trình duyệt hiện đại (Chrome, Firefox, Safari, Edge)
- 50MB dung lượng trống

---

## 🚀 Cài đặt & Triển khai / Installation & Deployment

### 1️⃣ **Cài đặt cơ bản (Basic Setup)**

#### A. Chạy cục bộ trên máy (Local)
```bash
# Tải file ZIP
# Giải nén vào thư mục

# Cách 1: Mở trực tiếp trong trình duyệt
open index.html  # macOS
start index.html # Windows
# hoặc kéo index.html vào trình duyệt

# Cách 2: Chạy HTTP server
# Sử dụng Python
python -m http.server 8000
# hoặc Node.js
npx http-server

# Mở trình duyệt: http://localhost:8000
```

#### B. Triển khai trên Vercel (Recommended) ⭐
```bash
# 1. Tạo tài khoản tại https://vercel.com
# 2. Cài đặt Vercel CLI
npm i -g vercel

# 3. Trong thư mục project
vercel

# 4. Làm theo hướng dẫn trên màn hình
# Kết quả: Website trực tiếp tại https://your-project.vercel.app
```

#### C. Triển khai trên GitHub Pages
```bash
# 1. Tạo repository GitHub
# 2. Đẩy tất cả files lên
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/username/repo-name.git
git push -u origin main

# 3. Trong Settings > Pages > chọn main branch
# Kết quả: Website tại https://username.github.io/repo-name
```

#### D. Triển khai trên Netlify
```bash
# Tải tất cả files
# Kéo & thả thư mục vào https://app.netlify.com
# Kết quả: Website tự động được đẩy lên
```

### 2️⃣ **Tùy chỉnh Cơ bản / Basic Customization**

#### 🎨 Thay đổi Logo & Tên Website

**File: `index.html`** (dòng 33-35)
```html
<div class="logo">
    THÔNG TIN AI  <!-- Sửa tên website ở đây -->
</div>
```

**File: `index.html`** (dòng 10)
```html
<title>THÔNG TIN AI</title>  <!-- Sửa tiêu đề tab browser -->
```

**File: `style.css`** (dòng 8-9)
```css
--primary:#2563eb;        /* Màu chính (blue) */
--primary-dark:#1d4ed8;   /* Màu chính tối hơn */
```

#### 🖼️ Thêm Logo/Hình ảnh tùy chỉnh

1. Thêm logo vào thư mục project
2. Sửa dòng 33 trong `index.html`:
```html
<div class="logo">
    <img src="your-logo.png" alt="Logo" style="height:50px;">
    Tên Website
</div>
```

#### 🔑 Thêm Favicon

`Favicon.svg` đã có sẵn! Để sử dụng:
```html
<!-- Thêm vào <head> trong index.html -->
<link rel="icon" type="image/svg+xml" href="favicon.svg">
```

#### 🌐 Cài đặt & Thêm Công cụ AI

**File: `data.js`**

Cấu trúc dữ liệu:
```javascript
const aiTools = [
    {
        id: "1",
        name: "ChatGPT",
        category: "chat",
        description: "Mô tả ngắn",
        fullDescription: "Mô tả chi tiết",
        website: "https://...",
        pricing: "Free + Paid",
        rating: 4.9,
        featured: true,
        free: true,
        newest: true
    },
    // Thêm công cụ khác...
];
```

**Các trường (Fields):**
| Trường | Kiểu | Ghi chú |
|--------|------|---------|
| `id` | String | ID duy nhất (không trùng) |
| `name` | String | Tên công cụ |
| `category` | String | chat/image/video/code/finance/study |
| `description` | String | Mô tả ngắn (100 ký tự) |
| `fullDescription` | String | Mô tả chi tiết (300+ ký tự) |
| `website` | String | URL chính thức |
| `pricing` | String | Free / Paid / Free + Paid |
| `rating` | Number | 0 - 5 (ví dụ: 4.8) |
| `featured` | Boolean | true/false - hiển thị ở Nổi bật |
| `free` | Boolean | true/false - AI miễn phí |
| `newest` | Boolean | true/false - AI mới |

**Ví dụ thêm công cụ:**
```javascript
{
    id: "42",
    name: "Gemini",
    category: "chat",
    description: "AI chat của Google",
    fullDescription: "Gemini là mô hình AI mạnh mẽ từ Google...",
    website: "https://gemini.google.com",
    pricing: "Free + Paid",
    rating: 4.7,
    featured: true,
    free: true,
    newest: false
}
```

#### 🌍 Thêm Ngôn ngữ Mới

**File: `translations.js`**

Cấu trúc:
```javascript
const translations = {
    vi: {
        "hero_title": "Khám phá thế giới AI",
        "hero_desc": "Tổng hợp những công cụ AI tốt nhất",
        // Thêm các dòng khác...
    },
    en: {
        "hero_title": "Discover AI World",
        "hero_desc": "Curated AI tools...",
        // Thêm các dòng khác...
    }
};
```

---

## 🎮 Sử dụng & Tính năng / Usage & Features

### 🔍 Tìm kiếm Công cụ
- Nhập tên công cụ hoặc từ khóa
- Kết quả tức thì, không cần reload

### 🏷️ Lọc theo Danh mục
- 💬 Chat AI
- 🎨 AI Hình ảnh
- 🎬 AI Video
- 💻 AI Lập trình
- 💰 AI Tài chính
- 📚 AI Học tập

### 💡 Tiện ích Nhanh
- 🏆 Bảng xếp hạng - Top AI được đánh giá cao
- 🆕 AI mới nhất - Công cụ được thêm gần đây
- 🎁 AI miễn phí - Chỉ công cụ free
- ❤️ Yêu thích - Lưu công cụ yêu thích
- 🕘 Đã xem gần đây - Lịch sử xem
- 🎲 Gợi ý ngẫu nhiên - Khám phá ngẫu nhiên

### 🌙 Chế độ Tối/Sáng
Bấm nút 🌙 ở góc trên phải

### 🌐 Đổi Ngôn ngữ
Chọn trong dropdown language selector

### ❤️ Yêu thích
- Bấm icon trái tim để lưu công cụ
- Lưu tự động trong Browser (localStorage)
- Xem trong mục "Yêu thích"

---

## 📁 Cấu trúc Thư mục / File Structure

```
project/
├── index.html          # Trang chính
├── style.css           # CSS chính
├── script.js           # JavaScript chính
├── data.js             # Dữ liệu công cụ AI
├── translations.js     # Dữ liệu ngôn ngữ
├── favicon.svg         # Icon trang web
├── 404.html            # Trang lỗi 404
├── loading.html        # Loading screen
├── README.md           # File này
├── vercel.json         # Config Vercel (tùy chọn)
└── .gitignore          # Git ignore file
```

---

## ⚙️ Các File Cấu Hình / Configuration

### Vercel Deployment (`vercel.json`)

Nếu muốn custom, tạo file `vercel.json`:
```json
{
  "buildCommand": "",
  "outputDirectory": ".",
  "public": true
}
```

### Custom Domain

Trên Vercel/Netlify:
1. Settings → Domain
2. Thêm domain của bạn
3. Sửa DNS records (hướng dẫn có sẵn)

---

## 🔧 Troubleshooting / Khắc phục lỗi

### ❌ Lỗi: Công cụ không hiển thị
**Nguyên nhân:** File `data.js` không load  
**Giải pháp:**
1. Kiểm tra đường dẫn file `data.js` trong `index.html`
2. Mở DevTools (F12) → Console, tìm lỗi
3. Kiểm tra format JSON trong `data.js`

### ❌ Lỗi: Ngôn ngữ không thay đổi
**Nguyên nhân:** File `translations.js` không đầy đủ  
**Giải pháp:**
1. Kiểm tra `translations.js` có tất cả các key không
2. Sửa chính tả key (phải khớp hoàn toàn)

### ❌ Lỗi: Mobile không responsive
**Nguyên nhân:** Viewport meta tag bị mất  
**Giải pháp:**
```html
<!-- Thêm vào <head> -->
<meta name="viewport" content="width=device-width, initial-scale=1.0">
```

### ❌ Trang loading chậm
**Giải pháp:**
1. Nén hình ảnh (tinypng.com)
2. Giảm số công cụ (nếu > 1000)
3. Dùng CDN cho hình ảnh
4. Minify CSS/JS (tùy chọn)

---

## 📊 Thống kê & Analytics

### Google Analytics (Tùy chọn)
```html
<!-- Thêm vào <head> -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'GA_ID');
</script>
```

---

## 🔒 Bảo mật / Security

### ✅ Đã kiểm tra:
- ✓ Không lưu dữ liệu cá nhân
- ✓ Không theo dõi người dùng
- ✓ Hoàn toàn client-side (không cần backend)
- ✓ HTTPS ready (khi deploy trên Vercel/Netlify)

### 📝 Privacy Policy
Thêm vào footer hoặc trang riêng nếu cần.

---

## 🤝 Hỗ trợ & Liên hệ / Support & Contact

Nếu gặp lỗi:
1. Kiểm tra Console (F12)
2. Kiểm tra file cấu hình
3. Xóa cache browser (Ctrl+Shift+Delete)

---

## 📄 License

Project này được cấp phép để sử dụng cá nhân và thương mại.  
Vui lòng giữ lại credit nếu có thể.

---

## 📈 Cải thiện trong tương lai / Future Improvements

- [ ] Admin dashboard để quản lý công cụ
- [ ] Backend API cho dữ liệu động
- [ ] User comments & ratings
- [ ] Email newsletter
- [ ] Mobile app
- [ ] Công cụ so sánh nâng cao

---

## 📝 Changelog

### v3.0 (Current)
- ✨ Giao diện mới, hiện đại
- 🎨 AI Hình ảnh, Video, Tài chính
- 🌐 2 ngôn ngữ hoàn toàn
- ❤️ Hệ thống Yêu thích
- 📊 Bảng xếp hạng
- 🌙 Chế độ tối

### v2.0
- Thêm AI Lập trình
- Tìm kiếm cải thiện

### v1.0
- Phiên bản đầu tiên

---

## 🙏 Cảm ơn / Thank You

- Fonts: Google Fonts (Poppins)
- Icons: Font Awesome
- Images: Flaticon

---

**Made with ❤️ for AI lovers**

*Last updated: July 30, 2026*
