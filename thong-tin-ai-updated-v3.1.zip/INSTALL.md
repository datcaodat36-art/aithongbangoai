# 🚀 Hướng Dẫn Cài Đặt & Triển Khai / Installation & Deployment Guide

## ⚡ Quick Start (5 phút)

### 1. **Chạy trên máy tính (Local)**
```bash
# Cách 1: Mở trực tiếp (Đơn giản nhất)
# Giải nén ZIP
# Bấp đúp vào file "index.html"

# Cách 2: Chạy server
# Python 3
python -m http.server 8000

# hoặc Node.js
npx http-server

# Mở: http://localhost:8000
```

### 2. **Deploy Vercel (Recommended) ⭐**
```bash
# 1. Tạo tài khoản: https://vercel.com
# 2. Cài CLI: npm i -g vercel
# 3. Chạy: vercel
# Kết quả: Website online trong 30 giây!
```

---

## 📚 Hướng dẫn Chi Tiết / Detailed Guide

### 🔷 I. CHẠY CỤC BỘ (Local)

#### **Cách 1: Mở trực tiếp (Đơn giản nhất)**
1. Giải nén file ZIP
2. Bấm đúp vào `index.html`
3. Hoàn tất!

**⚠️ Lưu ý:** Một số tính năng có thể không hoạt động (dùng Cách 2)

#### **Cách 2: Dùng Python (Recommended)**
```bash
# Python 3.x
python -m http.server 8000

# Python 2.x
python -m SimpleHTTPServer 8000

# Mở: http://localhost:8000
```

#### **Cách 3: Dùng Node.js**
```bash
# Cài đặt http-server
npm install -g http-server

# Chạy
http-server

# Mở: http://localhost:8080
```

#### **Cách 4: Dùng Live Server (VS Code)**
1. Cài extension "Live Server"
2. Chuột phải vào `index.html`
3. Chọn "Open with Live Server"

---

### 🔷 II. DEPLOY VERCEL (RECOMMENDED)

#### **Bước 1: Tạo tài khoản Vercel**
- Truy cập: https://vercel.com
- Đăng ký bằng GitHub/GitLab/Email

#### **Bước 2: Cài đặt Vercel CLI**
```bash
npm install -g vercel
```

#### **Bước 3: Triển khai**
```bash
# Di chuyển vào thư mục project
cd /đường/dẫn/project

# Chạy vercel
vercel

# Làm theo hướng dẫn:
# - Chọn "Other" cho project type
# - Nhấn Enter cho các tùy chọn mặc định
# - Chờ triển khai

# Kết quả: https://project-name.vercel.app
```

#### **Bước 4: Tuỳ chỉnh Domain (Tùy chọn)**
```
Vercel Dashboard → Settings → Domains → Add Domain
```

---

### 🔷 III. DEPLOY GITHUB PAGES

#### **Bước 1: Tạo Repository**
```bash
# Trên GitHub.com
# New Repository → thong-tin-ai
```

#### **Bước 2: Push code**
```bash
cd project-folder

git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/USERNAME/thong-tin-ai.git
git push -u origin main
```

#### **Bước 3: Kích hoạt Pages**
```
Repository Settings → Pages → Source: main branch → Save
```

**Kết quả:** https://USERNAME.github.io/thong-tin-ai

---

### 🔷 IV. DEPLOY NETLIFY

#### **Cách 1: Drag & Drop (Đơn giản nhất)**
1. Truy cập: https://app.netlify.com
2. Kéo thả thư mục vào
3. Hoàn tất! ✨

#### **Cách 2: Dùng CLI**
```bash
npm install -g netlify-cli
netlify deploy
```

---

## 🎨 TỰY CHỈNH WEBSITE

### 📝 1. Thay đổi Tên Website

**File: `index.html` (dòng 10 & 35)**
```html
<!-- Dòng 10: Tiêu đề tab browser -->
<title>THÔNG TIN AI</title>

<!-- Dòng 35: Logo trang -->
<div class="logo">THÔNG TIN AI</div>
```

**Thay đổi:**
```html
<title>AI Tools Vietnam</title>
<div class="logo">AI Tools Vietnam</div>
```

### 🎨 2. Thay đổi Màu Chính

**File: `style.css` (dòng 8-18)**
```css
:root {
    --primary: #2563eb;        /* Màu chính (Blue) */
    --primary-dark: #1d4ed8;   /* Màu tối hơn */
    --background: #f4f7fb;     /* Nền sáng */
    --white: #ffffff;
    --text: #1e293b;           /* Màu chữ */
    --gray: #64748b;           /* Màu xám */
    --border: #e5e7eb;
    --shadow: 0 15px 40px rgba(0,0,0,.08);
    --radius: 18px;
}
```

**Ví dụ thay đổi thành đỏ:**
```css
--primary: #dc2626;
--primary-dark: #991b1b;
```

### 🖼️ 3. Thêm Logo Tùy Chỉnh

```html
<!-- Thay dòng 35 -->
<div class="logo">
    <img src="logo.png" alt="Logo" style="height: 50px; margin-right: 10px;">
    AI Tools Vietnam
</div>
```

### 🔤 4. Thêm/Sửa Công Cụ AI

**File: `data.js`**

**Thêm công cụ mới:**
```javascript
const aiTools = [
    // ... công cụ cũ
    {
        id: "100",
        name: "Công Cụ Mới",
        category: "chat",
        description: "Mô tả ngắn",
        fullDescription: "Mô tả chi tiết...",
        website: "https://example.com",
        pricing: "Free",
        rating: 4.8,
        featured: true,
        free: true,
        newest: false
    }
];
```

**Các trường:**
| Trường | Kiểu | Ví dụ |
|--------|------|-------|
| `id` | String | "100" |
| `name` | String | "ChatGPT" |
| `category` | String | chat / image / video / code / finance / study |
| `description` | String | Ngắn 100 ký tự |
| `fullDescription` | String | Chi tiết 300+ ký tự |
| `website` | String | "https://..." |
| `pricing` | String | "Free" / "Paid" / "Free + Paid" |
| `rating` | Number | 4.8 |
| `featured` | Boolean | true / false |
| `free` | Boolean | true / false |
| `newest` | Boolean | true / false |

### 🌍 5. Thêm Ngôn Ngữ

**File: `translations.js`**

```javascript
const translations = {
    vi: {
        "hero_title": "Khám phá thế giới AI",
        "hero_desc": "Tổng hợp những công cụ AI tốt nhất",
        // Thêm các key khác...
    },
    en: {
        "hero_title": "Discover AI World",
        "hero_desc": "Curated AI tools...",
        // Thêm các key khác...
    },
    es: {  // Thêm ngôn ngữ mới (Tiếng Tây Ban Nha)
        "hero_title": "Descubre el mundo de la IA",
        "hero_desc": "Herramientas de IA seleccionadas...",
        // Thêm tất cả các key khác từ phía trên
    }
};

// Cập nhật danh sách ngôn ngữ hỗ trợ
const supportedLanguages = ["vi", "en", "es"];
```

---

## ✅ KIỂM TRA TRƯỚC KHI DEPLOY

### 📋 Checklist:
- [ ] Tất cả công cụ AI hiển thị
- [ ] Tìm kiếm hoạt động
- [ ] Chế độ tối/sáng hoạt động
- [ ] Đổi ngôn ngữ hoạt động
- [ ] Yêu thích lưu được
- [ ] Responsive trên mobile
- [ ] Không có lỗi Console (F12)
- [ ] Favicon hiển thị
- [ ] Loading screen xuất hiện & mất đi

### 🔧 Debug Console:
```javascript
// F12 → Console
// Kiểm tra dữ liệu công cụ
console.log(aiTools);

// Kiểm tra ngôn ngữ hiện tại
console.log(currentLang);

// Kiểm tra yêu thích
console.log(localStorage.getItem("favoriteTools"));
```

---

## 🐛 Sự Cố & Giải Pháp

### ❌ **Lỗi: Công cụ không hiển thị**
```
→ Kiểm tra Console (F12)
→ Xác nhận file data.js được tải
→ Kiểm tra format JSON trong data.js
```

### ❌ **Lỗi: Ngôn ngữ không thay đổi**
```
→ Kiểm tra translations.js có tất cả key
→ Sửa chính tả key (phải khớp hoàn toàn)
```

### ❌ **Lỗi: Mobile không responsive**
```
→ Thêm meta viewport:
<meta name="viewport" content="width=device-width, initial-scale=1.0">
```

### ❌ **Lỗi: Favicon không hiển thị**
```
→ Kiểm tra favicon.svg tồn tại
→ Xác nhận link: <link rel="icon" type="image/svg+xml" href="favicon.svg">
```

---

## 📊 TỐI ƯU HÓA HIỆU SUẤT

### ⚡ Nén hình ảnh:
- Dùng: https://tinypng.com
- Giảm kích thước ảnh 80%

### 🚀 Minify Code (Optional):
```bash
# CSS
npm install -g csso-cli
csso style.css -o style.min.css

# JavaScript
npm install -g terser
terser script.js -o script.min.js
```

### 📦 Dùng CDN cho hình ảnh:
Thay thế URLs địa phương bằng URLs Cloudinary/Imgur

---

## 🔐 AN TOÀN & BẢO MẬT

✅ **Đã được kiểm tra:**
- Không lưu dữ liệu cá nhân
- Không track người dùng
- Hoàn toàn client-side
- HTTPS sẵn sàng (Vercel/Netlify)

---

## 📞 LIÊN HỆ & HỖ TRỢ

**Gặp vấn đề?**
1. Kiểm tra Console (F12 → Console tab)
2. Xóa cache (Ctrl+Shift+Delete)
3. Thử trên trình duyệt khác
4. Kiểm tra lại các tệp cấu hình

---

## 📝 Công việc tiếp theo

- [ ] Triển khai lên Vercel
- [ ] Tùy chỉnh tên & màu sắc
- [ ] Thêm công cụ AI
- [ ] Kiểm tra trên mobile
- [ ] Đo hiệu suất (Google PageSpeed)

---

**Made with ❤️ for AI enthusiasts**

*Last Updated: July 30, 2026*
